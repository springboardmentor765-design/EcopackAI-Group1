// --- Eco Facts ---
const ecoFacts = [
  "Recycling one ton of cardboard saves over 9 cubic yards of landfill space.",
  "82% of consumers are willing to pay more for products with sustainable packaging.",
  "Compostable packaging can break down in as little as 90 days under industrial composting conditions.",
  "Switching from plastic to paper packaging can reduce carbon emissions by up to 60%.",
  "Reusable packaging systems can cut packaging waste by more than 80% in e-commerce logistics.",
  "Packaging made from bamboo or sugarcane bagasse is renewable and compostable.",
  "Recycled PET (rPET) packaging uses up to 75% less energy compared to virgin plastic production.",
  "Eco-friendly packaging reduces shipping weight, which lowers fuel consumption and CO₂ emissions."
];

function showRandomEcoFact() {
  const factBox = document.getElementById("ecoFactBox");
  if (!factBox) return;
  const randomFact = ecoFacts[Math.floor(Math.random() * ecoFacts.length)];
  factBox.innerHTML = "🌍 Eco Fact: " + randomFact;
}
setInterval(showRandomEcoFact, 10000);

// Homepage: Predict best materials 
async function getPrediction() {
  const weight = parseFloat(document.getElementById("productWeight").value);
  const category = document.getElementById("productType").value;

  if (!weight || weight <= 0 || !category) {
    alert("Please enter a valid weight and select a category.");
    return;
  }

  try {
    const response = await fetch("/recommend", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        product_weight_kg: weight,
        product_category: category
      })
    });

    const data = await response.json();
    const resultsDiv = document.getElementById("results");
    if (resultsDiv) resultsDiv.innerHTML = "";

    if (data.recommendations && data.recommendations.length > 0) {
      // Build table
      let tableHTML = `
        <table>
          <tr>
            <th><img src="/static/Material.png" alt="Material">Material</th>
            <th><img src="/static/Cost.png" alt="Cost">Cost Efficiency</th>
            <th><img src="/static/co2.png" alt="CO2">CO₂ Impact</th>
            <th><img src="/static/Score.png" alt="Score">Suitability Score</th>
          </tr>
      `;
      data.recommendations.forEach(item => {
        tableHTML += `
          <tr>
            <td>${item.Material_Type}</td>
            <td>${item.cost_efficiency_pred.toFixed(3)}</td>
            <td>${item.Co2_impact_index_pred.toFixed(3)}</td>
            <td>${item.suitability_score.toFixed(3)}</td>
          </tr>
        `;
      });
      tableHTML += `</table>`;
      if (resultsDiv) resultsDiv.innerHTML = tableHTML;

      showRandomEcoFact();

      // Render homepage comparison charts
      renderIndustryComparison(data.industry_baseline, data.recommendations);
    } else {
      if (resultsDiv) resultsDiv.innerHTML = `<p>No suitable materials found.</p>`;
    }
  } catch (err) {
    console.error("Prediction error:", err);
    if (document.getElementById("results")) {
      document.getElementById("results").innerHTML = `<p style="color:red">Error fetching predictions.</p>`;
    }
  }
}

// --- Homepage charts (baseline vs predicted) ---
function renderIndustryComparison(baseline, recommendations) {
  const materials = recommendations.map(r => r.Material_Type);
  const predictedCost = recommendations.map(r => r.cost_efficiency_pred);
  const predictedCo2 = recommendations.map(r => r.Co2_impact_index_pred);

  const baselineMaterials = Object.keys(baseline);
  const baselineCost = baselineMaterials.map(m => baseline[m].cost_efficiency);
  const baselineCo2 = baselineMaterials.map(m => baseline[m].co2_impact);

  Plotly.newPlot("industryCostChart", [
    { x: baselineMaterials, y: baselineCost, type: "bar", name: "Industry Baseline", marker: {color: "grey"} },
    { x: materials, y: predictedCost, type: "bar", name: "Predicted", marker: {color: "teal"} }
  ], {title: "Cost Efficiency: Industry vs Predicted"});

  Plotly.newPlot("industryCo2Chart", [
    { x: baselineMaterials, y: baselineCo2, type: "bar", name: "Industry Baseline", marker: {color: "grey"} },
    { x: materials, y: predictedCo2, type: "bar", name: "Predicted", marker: {color: "teal"} }
  ], {title: "CO₂ Impact: Industry vs Predicted"});

  // Ensure panel is shown when charts are ready
  const panel = document.getElementById("comparisonPanel");
  const layout = document.querySelector(".home-layout");
  panel.classList.add("active");
  layout.style.justifyContent = "space-around";
}

// --- Dashboard charts ---
function renderCharts(recommendations) {
  const materials = recommendations.map(r => r.Material_Type);
  const costEff = recommendations.map(r => r.cost_efficiency_pred);
  const co2Impact = recommendations.map(r => r.Co2_impact_index_pred);
  const suitability = recommendations.map(r => r.suitability_score);
  const biodegradability = recommendations.map(r => r.Biodegradability_Score);
  const recyclability = recommendations.map(r => r.Recyclability_Percent);

  const costColors = ["#1f77b4", "#17becf", "#6a51a3", "#3182bd", "#220bcf"];

  const recycleColors = ["#ffe082", "#ffb74d", "#f57c00", "#e64a19", "#b71c1c"];

  const suitabilityColors = ["#8288ff", "#ffba7a", "#7cff7c", "#ff7575", "#b672ff"];


  Plotly.newPlot("barChart", [{
    x: materials,
    y: costEff,
    type: "bar",
    marker: { color: costColors }
  }], { title: "Cost Efficiency" });

  // CO₂ Impact - Line
  Plotly.newPlot("lineChart", [{
    x: materials,
    y: co2Impact,
    type: "scatter",
    mode: "lines+markers",
    line: { color: "orange" }
  }], { title: "CO₂ Impact" });

  // Suitability Score Distribution - Pie
  Plotly.newPlot("pieChart", [{
    labels: materials,
    values: suitability,
    type: "pie",
    marker: { colors: suitabilityColors }
  }], { title: "Suitability Score Distribution" });


  // Biodegradability - Heatmap (low = light, high = dark)
  Plotly.newPlot("biodegradabilityChart", [{
    z: [biodegradability],
    x: materials,
    y: ["Biodegradability"],
    type: "heatmap",
    colorscale: [
      [0, "#e0f7e9"],
      [0.25, "#a5d6a7"],
      [0.5, "#66bb6a"],
      [0.75, "#2e7d32"],
      [1, "#1b5e20"]
    ],
    showscale: true
  }], {
    title: "Biodegradability",
  });

  // Recyclability - Horizontal Bar with warm shades
  Plotly.newPlot("recyclabilityChart", [{
    x: recyclability,
    y: materials,
    type: "bar",
    orientation: "h",
    marker: { color: recycleColors }
  }], { title: "Recyclability" });


}



// --- Compare button toggle ---
document.getElementById("compareBtn").addEventListener("click", () => {
  const panel = document.getElementById("comparisonPanel");
  const layout = document.querySelector(".home-layout");
  panel.classList.add("active"); // triggers CSS slide-in
  layout.style.justifyContent = "space-around"; // shifts to side-by-side
});