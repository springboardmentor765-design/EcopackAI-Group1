from flask import Flask, request, jsonify, render_template, session
import pandas as pd
import joblib

app = Flask(__name__)
app.secret_key = "super_secret_key"   # required for session storage

# Load dataset and feature engineering
material_df = pd.read_csv("finalmaterialsdataset.csv")

material_df['Co2_impact_index'] = material_df['CO2_Emission_Score'] * (1 - material_df['Recyclability_Percent'] / 100)
material_df["Cost_Normalized"] = (
    (material_df["Cost_per_unit"] - material_df["Cost_per_unit"].min()) /
    (material_df["Cost_per_unit"].max() - material_df["Cost_per_unit"].min())
)
material_df["Cost_Efficiency_Index"] = 1 - material_df["Cost_Normalized"]

FEATURES = [
    "Tensile_Strength_MPa",
    "Weight_Capacity_kg",
    "Moisture_Barrier_Grade",
    "Biodegradability_Score",
    "Recyclability_Percent"
]

# Load pre-trained models
cost_model = joblib.load("cost_model.pkl")
co2_model = joblib.load("co2_model.pkl")

# Routes
@app.route("/")
def home():
    return render_template("index.html")

@app.route("/dashboard")
def dashboard():
    recs = session.get("last_recommendations", [])
    baseline = session.get("last_baseline", {})
    return render_template("dashboard.html", recommendations=recs, industry_baseline=baseline)

@app.route("/recommend", methods=["POST"])
def recommend():
    data = request.get_json()
    product_weight_kg = data.get("product_weight_kg", 0)

    feasable_material = (material_df["Weight_Capacity_kg"] >= product_weight_kg)
    feasable_material_df = material_df[feasable_material].copy()

    if feasable_material_df.empty:
        return jsonify({
            "product_input": data,
            "recommendations": [],
            "message": f"No materials can support a product of {product_weight_kg} kg."
        })

    # Predictions
    x = feasable_material_df[FEATURES]
    feasable_material_df["Co2_impact_index_pred"] = co2_model.predict(x)
    feasable_material_df["cost_efficiency_pred"] = cost_model.predict(x)

    # Capacity utilization
    feasable_material_df["capacity_utilization"] = product_weight_kg / feasable_material_df["Weight_Capacity_kg"]

    # Normalization
    def safe_normalize(series):
        if series.max() == series.min():
            return series * 0
        return (series - series.min()) / (series.max() - series.min())

    feasable_material_df["co2_norm"] = safe_normalize(feasable_material_df["Co2_impact_index_pred"])
    feasable_material_df["cost_norm"] = safe_normalize(feasable_material_df["cost_efficiency_pred"])
    feasable_material_df["util_norm"] = safe_normalize(feasable_material_df["capacity_utilization"])

    # Suitability score
    feasable_material_df["suitability_score"] = (
        (0.5 * (1 - feasable_material_df["co2_norm"])) +
        (0.4 * feasable_material_df["cost_norm"] ) +
        (0.1 * feasable_material_df["util_norm"])
    )

    # Final ranking
    top_materials = (
        feasable_material_df.sort_values(by="suitability_score", ascending=False)
        .drop_duplicates(subset="Material_Type", keep="first")
        .head()
    )

    result = top_materials[[
        "Material_Type",
        "Co2_impact_index_pred",
        "cost_efficiency_pred",
        "suitability_score",
        "Biodegradability_Score",
        "Recyclability_Percent"
    ]].to_dict(orient="records")

    # Add baseline industry averages for homepage charts
    industry_baseline = {
    "Plastic":   {"cost_efficiency": 0.012, "co2_impact": 3.60},
    "Aluminum":  {"cost_efficiency": 0.014, "co2_impact": 3.50},
    "Glass":     {"cost_efficiency": 0.015, "co2_impact": 3.40}

}

    # Save predictions in session for dashboard
    session["last_recommendations"] = result
    session["last_baseline"] = industry_baseline

    return jsonify({
        "product_input": data,
        "recommendations": result,
        "industry_baseline": industry_baseline
    })


if __name__ == "__main__":
    app.run(debug=True)